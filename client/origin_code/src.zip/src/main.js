import Vue from 'vue'
import App from './App'
import router from './router'
import Calendar from './components/Calendar'
import Login from './components/Login'
import Rooms from './components/Rooms'
import BookForm from './components/BookForm'
import Employee from './components/Employee'

import Axios from 'axios'

Vue.prototype.$http = Axios

Vue.component('calendar', Calendar)
Vue.component('my-login', Login)
Vue.component('my-rooms', Rooms)
Vue.component('my-bookform', BookForm)
Vue.component('my-employee', Employee)


Vue.config.productionTip = false

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})