import Vue from 'vue'
import Router from 'vue-router'
import HelloWorld from '@/components/HelloWorld'
import Calendar from '@/components/Calendar'
import Rooms from '@/components/Rooms'
import Login from '@/components/Login'
import BookForm from '@/components/BookForm'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'HelloWorld',
      component: HelloWorld
    },
    {
      path: '/',
      name: 'Calendar',
      component: Calendar
    },
    {
      path: '/',
      name: 'Login',
      component: Login
    },
    
    {
      path: '/',
      name: 'Rooms',
      component: Rooms
    },
    {
      path: '/book-form',
      name: 'BookForm',
      component: BookForm
    }
  ]
})
