<template>
    <div class="div_rooms">
        <button type="button" id="js_btn1" name="room1" v-bind:class="['btn_room', currentRoom === 1?'yellow':'']"  @click="selectRoom(1)">room1</button>
        <button type="button" id="js_btn2" name="room2" v-bind:class="['btn_room', currentRoom === 2?'yellow':'']"  @click="selectRoom(2)">room2</button>
        <button type="button" id="js_btn3" name="room3" v-bind:class="['btn_room', currentRoom === 3?'yellow':'']"  @click="selectRoom(3)">room3</button>
    </div>
</template>
<script>
export default {
    props:['currentRoom'],
    methods: {
        selectRoom: function(id) {
           this.$emit("selRoom", id);
        }, 
    }
}

</script>