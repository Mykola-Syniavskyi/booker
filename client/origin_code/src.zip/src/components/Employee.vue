<template>
    
        <div class="conteiner">
 <!-- BUTTON GET EMPLOYEE            -->
            <h4>employee list</h4>
            <form method="GET" action="" id="employee_form">
                <input  type="button" @click="list=!list; getEmployees()" id="btn_employee" class="btn_show_employee" value="Employee list"/>
            </form><br>

            <div id="result_form_employee" class="result_form_employee"></div> 
<!-- LIST OF THE USERS -->
            
            <div  class='div_employee_list' v-show="list">
                <ul id="example-2">
                    <li v-for="(item, index) in employeeList[0]" :key="index">
                       <a href="#"> {{item.name}} </a>   <input type='button' value='REMOVE' class="remove_employee" @click="removeEmployee(item.id)"> <input type='button' value="Edit"   @click="show_edit=!show_edit, getId(item.id)">
                    </li>
                </ul>
<!-- EDD NEW EMPLOYEE -->
                <div class="form" id="div_ad_new_user" >
                    <h4>Adding new employee</h4>
                    <div id="result_form_reg" ><br></div>
                        <form method="POST" id="registration_form" action="" >
                            <input type="text" name="name"  placeholder="name" /><br>
                            <input type="text" name="role" placeholder="user/admin" /><br>
                            <input type="email" name="email" placeholder="email" /><br>
                            <input type="password" name="passwd" placeholder="passwd" /><br>
                            <input type="password" name="confirm_passwd" placeholder="confirm passwd" /><br>
                            <input type="button" id="btn_send" @click="registration()" class="btn_add" value="Add" />
                        </form><br>
                    </div>  
                <div class="add_user" >
                    <input class="btn_book_add_user" @click="show_add_new_user" id="btn_book_add_user" type="button" value="Add Employee">
                </div>
                </div>
            
 <!-- FORM EDIT EMPLOYEE            -->
            <div    v-show="!show_edit"> 
                <form action="" id="edit_employee">
                <input type="text"   v-model="userData.name" placeholder="name" /><br>
                <input type="text"  v-model="userData.role"  placeholder="user/admin" /><br>
                <input type="email"  v-model="userData.email"  placeholder="email" /><br>
                <input type="password"  value="" v-model="userData.passwd"  placeholder="passwd" /><br>
                <input type="button" id="btn_apply" @click="editEmployee(id)" class="btn btn-primary" value="Apply" />
            <br>
                </form>
            </div>

        </div>
        

   

</template>

<script>
import $ from 'jquery';
export default {
  name: "my-employee",
  data: function() {
    return {
      url: "http://tc.geeksforless.net/~user15/booker/client/api/booker/",
    //   url: "http://mysite.local/booker/server/api/booker/",
      employeeList:[],
      userData: {},
      show_edit: true,
      list:false,
      id:'',
      names:[]
      
     
      
    }
  },
  mounted() {
      this.getEmployees();
    //   this.getNamesEmployee();
  },
  methods: {
    getNamesEmpoyee(data){
        var name = [];
                data.forEach(function(item, i, data) {
                  
                name.push(item.name);
                });
                this.names.push(name); 

                 console.log(this.names[0]);
                this.$emit('getNames', 
                
                  this.names[0]
                );

    },

    getEmployees: function(){ 
            $('#div_ad_new_user').hide();
            $.ajax({
            url:this.url+'allEmployee/',
            method: 'GET',
            data: {
                
            },
            success: data => {

                //  console.log(data);
                this.buildEmployeeList(data);
                this.getNamesEmpoyee(data)
                
            },
            error: response=> {

                // console.log('ajax error');
            },
            complete: function() {
                // console.log('allways runned')
            }
            
            })
    },

    buildEmployeeList(data){
        data.forEach(element => {
            this.employeeList.push(data);
            });
        // console.log(this.employeeList);
    },

    editEmployee(id) {
        var userFormData = {
           user_id: id,
           name: this.userData.name,
           role: this.userData.role,
           email: this.userData.email,
           passwd: this.userData.passwd,
        };
                        $.ajax({

                        url:      this.url+'editEmployee', 
                        type:     "PUT", 
                        dataType: "html", 
                        data: userFormData,  

                        success: response => { 
                            // console.log(response);
                            var result = $.parseJSON(response);
                            if (result.success){
                                $('#result_form_employee').addClass('great').html(result.success);
                                $('form input[type="text"], form input[type="password"], input[type="email"] ').val('');
                            }else{
                                $('#result_form_employee').addClass('error').html(result.error);
                                $('form input[type="text"], form input[type="password"], input[type="email"] ').val('');
                            }
                                setTimeout(function() {window.location.reload();}, 2000);
                        },

                        error: function(response) { 
                        //  console.log(response);
                             $('#result_form_employee').html(response.error);
                        }

                    });
       
   },
       removeEmployee(id) {
        // console.log(id);
        
                        $.ajax({

                        url:      this.url+'Employee/'+ id, 
                        type:     "DELETE", 
                        dataType: "html", 

                        success: response => { 
                            // console.log(response);
                            var result = $.parseJSON(response);
                            if (result.success){
                                $('#result_form_employee').addClass('great').html(result.success);
                            }else{
                                $('#result_form_employee').addClass('error').html(result.error);
                            }
                                setTimeout(function() {window.location.reload();}, 2000)
                        },

                        error: function(response) { 
                        //   console.log(response);
                             $('#result_form_employee').html(response.error);
                        }

                    });
       
   },
   getId(id){
       this.id = id;
   },


   registration(result_form_reg, registration_form, url) {

                        $.ajax({

                        url:      this.url+'Reg', //url страницы 
                        type:     "POST", //метод отправки
                        dataType: "html", //формат данных
                        data: $("#"+'registration_form').serialize(),  // Сеарилизуем объект

                        success: response => { //Данные отправлены успешно

                            var result = $.parseJSON(response);
                            $('#registration_form')[0].reset();//clear form
                            // console.log(response);
                            if (result.success){
                            $('#result_form_reg').addClass("great").html(result.success);
                          

                            }else{
                                $('#result_form_reg').addClass("error").html(result.error);
                            }

                        },

                        error: function(response) { // Данные не отправлены
                        //  console.log(response.error);
                        
                             $('#result_form_reg').html(response.error);
                        }

                    });
       
   },
   show_add_new_user(){

       $('#div_ad_new_user').toggle();
   }
  },

}
</script>



 <style scoped>

.conteiner{
    background: lightblue;
}

.btn_show_employee, .btn_book_add_user, .btn_add {
    background: white;
    height: 30px!important;
    width: 100px!important;
    font-weight: 600;
    border-radius: 10px!important;
}
.btn_show_employee:hover, .btn_book_add_user:hover, .btn_add:hover{
    background:rgb(235, 255, 56);
    height: 31px!important;
    width: 104px!important;
}
.form {
  background:  lightblue;
  margin-top: 5%;
}
.form input {
  height: 30px;
  border-radius: 5px;
  
}

.great{
  background:rgb(235, 255, 56);
  width:200px;
}
.error{
  background: red;
  width:200px;
}
/* .fade-enter-active, .fade-leave-active {
  transition: opacity .5s;
} */

 </style>
