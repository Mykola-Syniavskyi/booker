<template>
    <div class="div_for_log">
        <!-- LOGIN FORM -->
        <h4>login Form</h4>
        <div id="result_form_log"><br></div>
        <form method="PUT" action="" id="log_form">
            <div class="form-group">
                <input type="email" class="form-control" id="exampleInputEmail1" name="email" placeholder="Enter email">
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="passwd" id="exampleInputPassword1" placeholder="Password">
            </div>
            <input  type="button" @click="sendPutAjax()" id="btn_log" class="btn btn-primary" value="Log in"/>
        </form><br>
    </div>
</template>

<script>
import $ from 'jquery';
export default {
  name: "Login",
  data: function() {
    return {
      url: "http://tc.geeksforless.net/~user15/booker/client/api/booker/",
      // url: "http://mysite.local/booker/server/api/booker/",
    }
  },
  methods: {
  
    sendPutAjax(){ 
         
        $.ajax({ 
            url:     this.url + 'log', //url страницы 
            type:     "PUT", 
            dataType: "html", 
            data: $("#log_form").serialize(),  
            success: response => { 
                var result = $.parseJSON(response);
                $('#log_form')[0].reset();//clear form
                if (result.error){
                    $('#result_form_log').addClass("error").html(result.error);
                    return false;
                }else{
                    localStorage.setItem('id', result[0].id);// add user to storage
                    localStorage.setItem('name', result[0].name);
                    localStorage.setItem('password', result[0].password);
                    localStorage.setItem('role', result[0].role);
                   window.location.reload();
                }
            },
            error: function(response) { 
                $('#result_form_log').html('Ошибка. Данные не отправлены.');
            }
        });
   }
  },
  
}
</script>



 <style scoped>

.great{
  background: rgb(235, 255, 56);
  z-index: 999;
}
.error{
  background: red;
  z-index: 999;
  width:200px;
}
.div_for_log{
    background: lightblue;
    width: 50%;
    margin: 0 auto;
}
#btn_log{
  background: white;
  height: 30px!important;
  width: 100px!important;
  font-weight: 600;
  border-radius: 10px!important;
}
#btn_log:hover{
  background:rgb(235, 255, 56);
  height: 31px!important;
  width: 104px!important;
}
 </style>
