<template >
 <div class="container">
    <div class="booker_form_update_container">
      <div class="booker_form_update" >
                  <div id="result_form_update"></div>        
                  <form method="PUT"  id="booker_form_update" >
                  <br>
                  <table v-if="selectedId" >
                      <tr ><td>Select Time Start:</td><td><input class="form-control" name="startTime" type="time" step="900" min="08:00" max="19:45" required="" v-bind:value="calcStartTime()"></td></tr>
                      <tr><td>Select Time End:</td><td><input class="form-control" name="endTime" type="time" step="900" min="08:15" max="20:00" required=""  v-bind:value="calcEndTime()"></td></tr>
                      <tr v-if="role =='admin'"><td>Name:</td><td><select  name="name" id="" >
                        <option   v-for="(name, index) in names[0]" :key="index" :value="name">{{name}}</option>
                      </select></td></tr>
                      <tr><td></td><td><input class="form-control" name="curent_user_name" type="hidden" v-model="curent_user_name"></td></tr>
                      <tr><td></td><td><input class="form-control" name="event_id" type="hidden" v-model="selectedEvent.id"></td></tr>
                      <tr><td></td><td><input class="form-control" name="user_id" type="hidden" v-model="selectedEvent.user_id"></td></tr>
                      <tr><td></td><td><input class="form-control" name="role" type="hidden" v-model="role"></td></tr>
                      <tr><td>Note: </td><td><textarea class="form-control" type="text" name="note" v-model="selectedEvent.note"></textarea><br></td></tr>
                      <tr ><td>submited:</td> <td name="created">{{selectedEvent.created_data}}</td></tr>
                  </table><br>
                  <!-- IN RECURENT CASE SHOW CHECK BOX -->
                  <table  v-if="selectedEvent.recurent_id">
                      <tr><td>Is recurent?</td><td></td></tr>
                      <tr><td> </td><td></td></tr>
                      <tr><td>no:</td><td><input name="recurent" type="radio" value="0"  v-model="picked"></td></tr>
                      <tr><td>yes:</td><td><input name="recurent" type="radio" value="1" v-model="picked"></td></tr>
                  </table>                  
                  <button class="btn_book_add" type="button" @click="Update_event">Update Event</button>
                  <button class="btn_book_add" type="button" @click="Delete_event">Delete Event</button>
                  <button class="btn_book_add" type="button" @click="Cancel_Update">Close</button>

              </form>
    </div>
  </div>
  <my-login v-show="!this.curent_user_name"></my-login>
    <div class="col-md-4" v-show="this.curent_user_name">
      <h1>Room`s <span>booker</span>  </h1>

<!-- BUTTON FOR CHANGE START WEEK -->
          <div class="log_out">
            <h2 class="h2">Hello :<span class="span_for_name"> {{curent_user_name}}</span> <input type="button" value="LOG OUT" @click="Clear_storage" class="btn_log_out"></h2>  
          </div>
          
      <div class="form_rooms">
<!-- <div class="div_rooms"> -->
          <my-rooms v-show="this.curent_user_name" @selRoom="selectRoom" v-bind:currentRoom="currentRoom"></my-rooms>
          <my-employee v-show="this.curent_user_name" @getNames="getNames" v-if="role =='admin'"></my-employee>
          <my-bookform v-show="this.curent_user_name"></my-bookform>

      </div>
        
        <!-- <my-registration></my-registration> -->
        
      </div><br>
    
      <div class="table-responsive" v-show="this.curent_user_name">
          
        <div class="swicher">
            Week start<input type="checkbox" id="button-swicher" v-model="start" >
            
        </div>
            <div class="btn_room"></div> 
            <div class="activeRoom ">Boardroom {{currentRoom}}</div>
       
        <table class="table table-bordered">
          <thead class="thead-default">
              <tr>
                  <th colspan="1" height="20px">
                      <a href="#" class="prev" @click="previousMonth">&lt;</a>
                  </th>
                  <th colspan="5" class="center-title">
                      {{currentMonthAndYear}}
                  </th>
                  <th colspan="1">
                      <a href="#" class="next" @click="nextMonth">&gt;</a>
                  </th>
              </tr>

        <!-- SHOW NAMES OF DAYS -->
              <tr v-if="startW == 6">
                  <th v-for="(day, index) in daysMon" :key="index">{{day}}</th>
              </tr>
              <tr v-else>
                  <th v-for="(day, index) in daysSun" :key="index">{{day}}</th>
              </tr>
          </thead>
		  
		  
          <tbody class="tbody-default" data-bind="foreach:gridArray">
            <tr v-for="(item, index) in gridArray" :key="index" class="tr_for_height">
              <td :class="{'yellow':isWeekend(data)}" v-for="(data, index) in item" :key="index"  class="td_calendar">
          
                  <span  v-if="data.d.getMonth() == selectedDate.getMonth()" class="container_for_data">
                
                      <div class="div_for_date_month">
                          {{data.d.getDate()}}<br />
                      </div>
                    <!-- SHOW FORM FOR UPDATING EVENT -->
                      <div class="js-c-event" v-for="(e,index) in data.e" :key="index">
                        <a href="#"  @click="showEvent(e.id)" >
                         <!-- DROW EVENTS IN THE CALENDAR  -->
                            {{e.start.getHours()}}:{{('0'+e.start.getMinutes()).slice(-2)}} - {{e.end.getHours()}}:{{('0'+ e.end.getMinutes()).slice(-2)}}<br />
                            
                        </a>
                      </div>
                  
                  </span>

                  <span class="nocurrmonth" v-if="data.d.getMonth() != selectedDate.getMonth()">
                        <a href="#" >
                        {{data.d.getDate()}}
                    </a>
                  </span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div >
    </div>
    </div>
</div>


</template>
<script>
import $ from 'jquery'; 
export default {
  name: 'calendar',
  
  data () {
			return{
            picked: null,
            role: localStorage.getItem('role'),
            curent_user_name: localStorage.getItem('name'),// NAME AFTER LOGIN
						filterDate: undefined,
						selectedDate: new Date(),	
						curentMon:this.mnn(),
            curentYear:this.yearnow(),
            day: new Date().getDate(),
            currentMonthAndYear: this.getMonth(this.curentMon)+' '+this.curentYear,	
            daysMon:  ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],
            daysSun: ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
            startW: 6,
            start: false,
            currentRoom: 1,
            visible: false,
            selectedId: undefined,
            resultEvents:[],
            names: [],
            url: "http://tc.geeksforless.net/~user15/booker/client/api/booker/",
            // url: "http://mysite.local/booker/server/api/booker/",
           
            
			}
  },
  

  methods: {
    Clear_storage(){
      localStorage.clear();
      window.location.reload();
    },
    calcStartTime(){
      if (Object.keys(this.selectedEvent).length == 0) {
        return;
      }
      return ('0'+ this.selectedEvent.start.getHours()).slice(-2)+':'+('0' + this.selectedEvent.start.getMinutes()).slice(-2);
    },

    calcEndTime(){
      if (Object.keys(this.selectedEvent).length == 0) {
        return;
      }
      return ('0'+this.selectedEvent.end.getHours()).slice(-2)+':'+('0'+this.selectedEvent.end.getMinutes()).slice(-2);
    },

    getNames(Name) {console.log(Name);
    this.names.push(Name);
  },




      Update_event(){ 
         
        $.ajax({ 
            url:     this.url + 'eventUpdate', 
            type:     "PUT", 
            dataType: "html", 
            data: $("#booker_form_update").serialize(), 
            success: response => { 
                var result = $.parseJSON(response);
                $('#booker_form_update')[0].reset();//clear form
                 console.log(result);
                if (result.success){
                                $('#result_form_update').addClass('great').html(result.success);
                            }else{
                                $('#result_form_update').addClass('error').html(result.error);
                            }
                                setTimeout(function() {window.location.reload();}, 3000)
                if (result.error){
                    $('#result_form_log').addClass("error").html(result.error);
                    return false;
                }
            },
            error: function(response) { 
                $('#result_form_log').html('Ошибка. Данные не отправлены.');
                 $('.booker_form_update_container').toggle();
            }
        });
   },

      selectRoom(id){
         $('form input[type="time"], form input[type="hidden"], form input[type="radio"], form textarea, form [name="created"] ').val('');
         return this.currentRoom=id;

      },

      showEvent(id){
        this.selectedId=id;

          $('.booker_form_update_container').toggle();

      },
      Cancel_Update(){
        $('.booker_form_update_container').toggle();
      },

      Delete_event(){
        $.ajax({ 
            url:     this.url + 'eventDelete/'+ this.selectedEvent.id + '/'+ this.role + '/'+ this.picked + '/'+this.curent_user_name,  //url страницы 
            type:     "DELETE", 
            dataType: "html", 
            success: response => { 
                            // console.log(response);
                            var result = $.parseJSON(response);
                            if (result.success){
                                $('#result_form_update').addClass('great').html(result.success);
                            }else{
                                $('#result_form_update').addClass('error').html(result.error);
                            }
                            //  $('.booker_form_update_container').toggle();
                                 setTimeout(function() {window.location.reload();}, 3000)
                        },

                        error: function(response) { 
                             $('#result_form_employee').html(response.error);
                              $('.booker_form_update_container').toggle();
                        }

                    });
      },
    
      getMonth(n) {
          var months =  ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Now','Dec'];
          return months[n];
        },
      
      
      yearnow() {
          this.curentYear = (new Date()).getFullYear();
          return (new Date()).getFullYear();
      },
      mnn() {
          this.curentMon = (new Date()).getMonth();
          return (new Date()).getMonth();
      },
      
      previousMonth: function() {
          var tmpDate = this.selectedDate;
          var tmpMonth = tmpDate.getMonth() - 1;
          this.selectedDate = new Date(tmpDate.setMonth(tmpMonth));
          this.selectedDate.setMonth(tmpMonth);
          this.getEvents(this.selectedDate.getMonth(), this.currentRoom, this.selectedDate.getFullYear());
          this.currentMonthAndYear = this.getMonth(this.selectedDate.getMonth())+' '+this.selectedDate.getFullYear();
          // CALL TO GET EVENTS
        },
	
      nextMonth: function() {
          var tmpDate = this.selectedDate;
          var tmpMonth = tmpDate.getMonth() + 1;
          this.selectedDate = new Date(tmpDate.setMonth(tmpMonth));
          this.getEvents(this.selectedDate.getMonth(), this.currentRoom, this.selectedDate.getFullYear());
          this.currentMonthAndYear = this.getMonth(this.selectedDate.getMonth())+' '+this.selectedDate.getFullYear();
// CALL TO GET EVENTS

	},
	
	
	
      setDate: function(date) {
          if (date == this.filterDate) {
          this.filterDate = undefined;
          //unselected
      } else {
        this.filterDate = date;
      }
    },
	
	    isWeekend: function(date) {
          return ((date.d.getDay() == 0) || (date.d.getDay() == 6));
      },


      getCalendar: function(date) {

        this.getEvents(this.selectedDate.getMonth(), this.currentRoom, this.selectedDate.getFullYear());
        var calendar = [];


          var startDay = new Date(date.getFullYear(), date.getMonth(), 1);
          var lastDay = new Date(date.getFullYear(), date.getMonth() + 1, 0);

          //CHANGE  START WEEK
          if (this.start == true){
            this.startW = 0;
          }else{
            this.startW = 6;
          }
         // Modify the result of getDay so that we treat Monday = 0 instead of Sunday = 0
      
          var startDow = (startDay.getDay() + this.startW) % 7;
          //  console.log(this.startW);
          var endDow = (lastDay.getDay() + 6) % 7;//console.log(endDow);

          // If the month didn't start on a Monday, start from the last Monday of the previous month
          startDay.setDate(startDay.getDate() - startDow);

          // If the month didn't end on a Sunday, end on the following Sunday in the next month
          lastDay.setDate(lastDay.getDate() + (6 - endDow));

          //INISIALE ARRAY FOR EVENT
          var eventData =[];
          var week = [];

          while (startDay <= lastDay) {
            var $event = [];
              var room = this.currentRoom;
       
              //добавляем события к датЕ если есть в MonthEventsList
              console.log(typeof this.resultEvents);
              if ( typeof this.resultEvents == 'object'  && this.resultEvents.length !== null){
                  this.resultEvents.forEach(function(item, i, resultEvents) {
                      item.start = new Date(Date.parse(item.start));
                      item.end = new Date(Date.parse(item.end));
                      var d1 = item.start
                      var d2 = startDay;
                      if (d1.getMonth() == d2.getMonth())
                      if (item.room_id == room && d1.getDate() == d2.getDate()) {
                        $event.push(item);
                        }
                    });
                  week.push({d:new Date(startDay),e: $event}); //пушим событие к дате
                }else{
                  week.push({d:new Date(startDay)});
                }
        
          if (week.length === 7) {
            calendar.push(week);
              week = []
          }
          startDay.setDate(startDay.getDate() + 1)
        }
        return calendar;
      },
    

      getEvents($monthEvent,$currentRoom, $curentYear){ 
          $.ajax({
              url: this.url +'allEvents/'+($monthEvent+1)+'/'+$currentRoom +'/'+ $curentYear ,
              async:false,
              method: 'GET',
              data: {
                  
              },
              success: data => {
                 console.log('EVENTS', data, $monthEvent,$currentRoom,$curentYear);
                  this.resultEvents = data || [];

              },
              error: response=> {
              },
              complete: function() {
              }
          });
      }
       
  },
  components: {
    
    Login:'my-login',
    Rooms: 'my-room',
    Employee: 'my-employee'
  },

  computed: {
    // a computed getter
      gridArray: function() {
        var grid = this.getCalendar(this.selectedDate);
          return grid;
      },
    
     //make 
      selectedEvent() {
        let event = this.resultEvents.filter(e => {return e.id == this.selectedId} )[0] || {};

        if (typeof(event.start) == 'string') {
          event.start = new Date(Date.parse(event.start));
        }

        if (typeof(event.end) == 'string') {
          event.end = new Date(Date.parse(event.end));
        }

        return event;
      },
	
  }  

}
</script>

<style >
.tr_for_height{
  height: 130px!important;
}
.container_for_data{
  font-weight: 500;
}
.div_for_date_month{
  color: #000;
  clear: both;
  width:120px;
 
}
span{
  color:yellow;
  
}
h1{
  font-weight:800;
  letter-spacing: 5px;
  color: lightblue;
  text-shadow: -2px 0 black, 0 1px black, 2px 0 black, 0 -1px black;
}

.activeRoom{
  background: yellow;
  font-weight: 700;
  float:right;
  display: block;
  width:75%;
  height: 40px;
}

.td_calendar:hover{
  background: rgb(211, 211, 211);

  }

#button-swicher{
margin-right: 80%;
}
.div_rooms{
    background: lightblue;
    /* height: 100px;
    padding-top: 3px; */
    /* width: 15%; */
}
.btn_room{
  display: block;
  width: 75%;
  height: 30px;
  margin: 2px auto;
 
  
}
.swicher{
    background: lightblue;
    height: 40px;
    width: 75%;
    font-weight: 700;
    float:right;
    /* display:block; */
   
    
}
.form_rooms{
  background:  lightblue;
  margin-top: 5%;
  width : 20%;
  float: left;
}
.table-bordered{
background:linear-gradient(#000,#ccc,#fff);
box-shadow:2px 3px 7px #888;
border-radius:5px;
width:75%;
min-height: 500px;
float:right;
}

.yellow {
background:rgb(235, 255, 56);
color:black;
}
.yellow a{color:black;}

/* .fade-enter-active,
.fade-leave-active {
  transition: opacity .5s
}

.fade-enter,
.fade-leave-active {
  opacity: .3
  
} */

.thead-default, .thead-default a {
  background: lightblue;
  color:black;
}
.h2 {
   background: lightblue;
   width: 30%;
    
}
.span_for_name{
    text-decoration: underline;
}
.btn_log_out{
  display: inline;
  background: white;
    height: 30px!important;
    width: 100px!important;
    font-weight: 600;
    border-radius: 10px!important;
}
.btn_log_out:hover{
  background:rgb(235, 255, 56);
    height: 31px;
    width: 104px;
}


.tbody-default {
  background: lightskyblue;
  
}

a {
  padding: 0px 10px 0px 10px;
}

.center-title {
  text-align: center;

}

.nocurrmonth a {
color:#aaa;
text-decoration:none;
}
.js-c-event {
  
  color:#fff;
  width: fit-content;
}

.booker_form_update{
  background:rgb(198, 238, 255);
  width: 400px;
  position: relative;
  left: 30%;
  top:20%;

}
.booker_form_update_container{
position: absolute;
top:10%;
width: 100%;
height: 150%;
background: rgba(136, 136, 136, 0.61);
display: none;
}

.great{
  background:rgb(235, 255, 56);
  z-index: 999;
  width:200px;
}
.error{
  background: red;
  z-index: 999;
  width:200px;
}


</style>
