<template>
    <div class="booker_form_div" >
        <button type="button" id="show_book_form" @click="show_book_form" class="show_book_form" title="show or close form">Book It</button>
        <div id="result_form_book"></div>        

        <form method="POST"  id="booker_form" class="form" >
         <br>
        <table>
            <tr><td>Select room:</td>
            <td><select  name="room">
                <option disabled selected>Choose room</option>
                <option value="1">room1</option>
                <option value="2">room2</option>
                <option value="3">room3</option>
                </select>
            </td></tr>
            <tr><td>Select date:</td><td><input class="form-control" name="startDay" type="date"   :min="min_date()" required="" value=""></td></tr>
            <tr><td>Select Time Start:</td><td><input class="form-control" name="startTime" type="time" step="900" min="08:00" max="19:45" required="" value=""></td></tr>
            <tr><td>Select Time End:</td><td><input class="form-control" name="endTime" type="time" step="900" min="08:15" max="20:00" required="" value=""></td></tr>
            <tr><td></td><td><input class="form-control" name="user_id" type="hidden" v-model="this.user_id"></td></tr>
            <tr><td>Note: </td><td><textarea class="form-control" name="note"></textarea><br></td></tr>
            <tr><td>Is recurent?</td><td></td></tr>
            <tr><td> </td><td></td></tr>
            <tr><td>no:</td><td><input name="recurent" type="radio" value="0"  v-model="visible" ></td></tr>
            <tr><td>yes:</td><td><input name="recurent" type="radio" value="1" v-model="visible"></td></tr>
        </table><br>
         
       <div id="recurent" v-show="visible == '1'">
            <table>
                <tr><td>weekly:</td><td><input name="times" type="radio" value="WEEKLY"></td></tr>
                <tr><td> 2-weekly:</td><td><input name="times" type="radio" value="BI-WEEKLY"></td></tr>
                <tr><td>monthly: </td><td><input name="times" type="radio" value="MONTHLY"></td></tr>
                <tr><td>Repeat count:</td><td><input class="form-control" name="duration" type="number" min="1" max="4"></td></tr>
            </table>
       </div><br>
        
        <button class="btn_book_add" type="button" @click="addEvent">Add Event</button>

    </form>
    </div>
</template>

 <script>
    import $ from 'jquery';


export default {
  name: 'my-bookform',
  
  data () {
			return{
                visible:false, 
                url: "http://tc.geeksforless.net/~user15/booker/client/api/booker/",
                // url: "http://mysite.local/booker/server/api/booker/",     
                user_id: localStorage.getItem('id'),
                day: new Date().getDate(),
                month: (new Date().getMonth()+1) % 12,
                year:  new Date().getFullYear(),
               
                 
            }
  },
  
  methods: {
    min_date(){
        if (this.month < 10){
           var  min_time = this.year +'-0' +this.month+'-'+this.day;
        }else{
            var min_time = this.year +'-' +this.month+'-'+this.day;
        }
        return min_time;
    },
	show_book_form(){
        $('#result_form_book').html('');//clear result form
        $('#booker_form').toggle("slow") ;
    },
    addEvent(result_form_book, booker_form, url) {
                        $('#result_form_book').html('');//clear result form
                        $.ajax({

                        url:      this.url+'addEvent', 
                        type:     "POST", 
                        dataType: "html", 
                        data: $('#booker_form').serialize(),  

                        success: response => { 

                            var result = $.parseJSON(response);
                            $('#booker_form')[0].reset();//clear form
                            if (result.success){
                            $('#result_form_book').addClass("great").html(result.success);
                            setTimeout(function() {window.location.reload();}, 1000);
                            }else{
                                $('#result_form_book').addClass("error").html(result.error);
                            }
                        },

                        error: function(response) { 
                             $('#result_form_book').addClass("error").html(response.error);
                        }

                    });
       
   },

  },
}
</script>

<style scoped>
table{
    text-align: left;
}
.btn_book_add, .btn_book_edit, .btn_book_del, .show_book_form {
    background: white;
    height: 30px;
    width: 100px;
    font-weight: 600;
    border-radius: 10px;
}
.btn_book_add:hover, .btn_book_edit:hover, .btn_book_del:hover, .show_book_form:hover{
    background:rgb(235, 255, 56);
    height: 31px;
    width: 104px;
}
.booker_form_div{
    background: lightblue;
    height: 40%;
}
#recurent{
    height: 60%;
}
#booker_form{
    display: none;
}
.great{
  background:rgb(235, 255, 56);
  z-index: 999;
  width:200px;
}
.error{
  background: red;
  z-index: 999;
  width:200px;
}
.form {
  background:  lightblue;
  margin-top: 5%;
}
.booker_form_div {
    background: lightblue;
    height: 40%;}

</style>
